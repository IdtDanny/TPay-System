import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.serial.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class processingProgram extends PApplet {


Serial arduino;

String card="LOADING...";
String response="CHECKING";

public void setup(){
  size(400,200);
  background(0xff3264C6);
  arduino=new Serial(this,"COM3",115200);
}
public void draw(){
 if(arduino.available()>0){
    String data=arduino.readString();
    if(data!=" "){
      data=data.substring(1,data.length());
      data=data.replace(" ","");
      println(data);// print data from arduino
      
      String[] send=loadStrings("http://localhost/cps/check.php?id="+data);
      delay(500);
      if(send.length>0){
        if(send[0].indexOf("ok")!=-1){
          response="Known User";
          link("http://localhost/cps/login.php?id="+send[0]);
        }else{
          response="Unknown User";
        }
      }
      card=data;
      println(send[0]);
    }
  }
  smooth();
  noStroke();
  textSize(20);
  fill(255);
  text("Welcome To TAP&PAY SYSTEM",25,25);

  stroke(255);
  rect(25,35,width-55,height-75);
  
  //status
  fill(0xff4B49C4);
  text("ID ="+card,40,75);
  fill(0xffFC0A0E);
  text("Result ="+response,40,135);
  fill(255);
  text("copyright reserved by Obed 2018",40,height-10);  

  
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "processingProgram" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
